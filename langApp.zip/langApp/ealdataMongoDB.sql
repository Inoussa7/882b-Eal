{
  "Type": "Lesson",
  "LessonID": 1,
  "TopicID": 101,
  "ProficiencyLevelID": 201,
  "Title": "Basic Vocabulary",
  "Content": "This lesson covers basic vocabulary words...",
  "ExerciseDescription": "Match the words with their meanings...",
  "ExerciseSolution": "1 - A, 2 - B, 3 - C...",
  "URL": "https://example.com/basic_vocabulary",
  "ExerciseType": "Vocabulary"
},
{
  "Type": "Lesson",
  "LessonID": 2,
  "TopicID": 102,
  "ProficiencyLevelID": 202,
  "Title": "Introduction to Tenses",
  "Content": "This lesson introduces different verb tenses...",
  "ExerciseDescription": "Fill in the blanks with the correct tense...",
  "ExerciseSolution": "1 - Present Simple, 2 - Past Continuous...",
  "URL": "https://example.com/intro_tenses",
  "ExerciseType": "Grammar"
},
{
  "Type": "Exercise",
  "ExerciseID": 1,
  "TopicID": 103,
  "ProficiencyLevelID": 203,
  "Title": "Reading Comprehension: The Cat and the Hat",
  "Passage": "Once upon a time, there was a cat...",
  "Questions": "1. What did the cat wear?...",
  "Answers": "1. A hat...",
  "URL": "https://example.com/reading_exercise",
  "ExerciseType": "Reading"
},
{
  "Type": "Exercise",
  "ExerciseID": 2,
  "TopicID": 104,
  "ProficiencyLevelID": 204,
  "Title": "Listening Comprehension: Conversation at the Cafe",
  "Audio": "<binary_audio_data>",
  "Video": "<binary_video_data>",
  "Transcript": "Waiter: Welcome to Cafe Paris...",
  "URL": "https://example.com/listening_exercise",
  "ExerciseType": "Listening"
}
