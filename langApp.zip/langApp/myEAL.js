document.addEventListener('DOMContentLoaded', function() {
    fetchDataAndPopulateUI();
    setupFormListeners();
    displayRandomAffirmation();
});

let languageLearningContent;
let grammarLearningContent;
let travelResourcesForLearningStyles;

function fetchDataAndPopulateUI() {
    fetch('eaL.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            populateProficiencyLevels(data.proficiencyLevels);
            populateLearningStyles(data.learningStyles);
            populateCountryDropdown();

            const storedUserProfiles = JSON.parse(localStorage.getItem('userProfiles'));
            if (storedUserProfiles) {
                displayUsers(storedUserProfiles);
            } else {
                loadUserProfiles(data.users);
                displayUsers(data.users);
            }

            // Store the loaded JSON data in variables
            languageLearningContent = data.languageLearningContent;
            grammarLearningContent = data.grammarLearningContent;
            travelResourcesForLearningStyles = data.travelResourcesForLearningStyles;
        })
        .catch(error => console.error('Error fetching data:', error));
}

function loadUserProfiles(users) {
    localStorage.setItem('userProfiles', JSON.stringify(users));
}

function handleSignupFormSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const newUser = {
        name: formData.get('name'),
        password: formData.get('password'),
        countryofOrigin: formData.get('countryofOrigin'),
        languagesSpoken: formData.get('languagesSpoken').split(','),
        major: formData.get('major'),
        specialization: formData.get('specialization'),
        classes: formData.get('classes').split(',')
    };
    const userProfiles = JSON.parse(localStorage.getItem('userProfiles')) || [];
    userProfiles.push(newUser);
    localStorage.setItem('userProfiles', JSON.stringify(userProfiles));
    displayUsers(userProfiles);
}

function populateCountryDropdown() {
  fetch('https://restcountries.com/v3.1/all')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(countries => {
      // Sort countries alphabetically by name
      countries.sort((a, b) => a.name.common.localeCompare(b.name.common));
      
      const dropdown = document.getElementById('countryDropdown');
      
      countries.forEach(country => {
        dropdown.add(new Option(country.name.common, country.name.common));
      });
    })
    .catch(error => console.error('Error fetching country list:', error));
}

function populateProficiencyLevels(levels) {
    const dropdown = document.getElementById('proficiencyLevel');
    levels.forEach(level => {
        dropdown.add(new Option(level, level));
    });
}

function populateLearningStyles(styles) {
    const dropdown = document.getElementById('learningStyle');
    Object.entries(styles).forEach(([style, description]) => {
        dropdown.add(new Option(style, style));
    });
}

function setupFormListeners() {
    document.getElementById('learningForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const learningStyle = document.getElementById('learningStyle').value;
        const proficiencyLevel = document.getElementById('proficiencyLevel').value;
        displayLearningContent(learningStyle, proficiencyLevel);
    });

    document.getElementById('signUpButton').addEventListener('click', toggleSignupFormVisibility);
    document.getElementById('signUpForm').addEventListener('submit', handleSignupFormSubmit);
    document.getElementById('loginForm').addEventListener('submit', handleLoginFormSubmit);
    document.getElementById('showAllProfilesButton').addEventListener('click', showAllUserProfiles);
}

// Function to generate dropdown from JSON data
function generateDropdown(containerId, options) {
  const dropdown = document.createElement("select");
  dropdown.id = containerId;
  
  options.forEach(option => {
    const optionElem = document.createElement("option");
    optionElem.value = option;
    optionElem.textContent = option;
    dropdown.appendChild(optionElem);
  });

  document.getElementById(containerId).appendChild(dropdown);
}

// Generate learning style dropdown
generateDropdown("learningStyleDropdown", Object.keys(learningStyles));

// Generate proficiency level dropdown
generateDropdown("proficiencyLevelDropdown", proficiencyLevels);

// Function to display tailored content based on user selection
function displaySelectedContent() {
  // Get selected learning style and proficiency level
  const learningStyle = document.getElementById("learningStyleDropdown").value;
  const proficiencyLevel = document.getElementById("proficiencyLevelDropdown").value;
  
  // Call the displayLearningContent function with user-selected parameters
  displayLearningContent(learningStyle, proficiencyLevel);
}

const { Duolingo } = require('@grimille/duolingo-js');

function displayLearningContent(learningStyle, proficiencyLevel) {
    const topic = "Travel";

    if (languageLearningContent && languageLearningContent[topic] && languageLearningContent[topic][proficiencyLevel]) {
        const writingPrompt = languageLearningContent[topic][proficiencyLevel].WritingPrompt || "No writing prompt available for this level.";
        const vocabExercise = languageLearningContent[topic][proficiencyLevel].VocabularyExercise || "No vocabulary exercise available for this level.";

        const grammarExplanation = (grammarLearningContent && grammarLearningContent["Tenses"] && grammarLearningContent["Tenses"][proficiencyLevel])
            ? grammarLearningContent["Tenses"][proficiencyLevel].Explanation || "No grammar explanation available for this level."
            : "No grammar explanation available for this level.";

        const grammarExercise = (grammarLearningContent && grammarLearningContent["Tenses"] && grammarLearningContent["Tenses"][proficiencyLevel])
            ? grammarLearningContent["Tenses"][proficiencyLevel].Exercise || "No grammar exercise available for this level."
            : "No grammar exercise available for this level.";

        const resources = travelResourcesForLearningStyles && travelResourcesForLearningStyles[learningStyle]
            ? travelResourcesForLearningStyles[learningStyle]
            : {};

        let resourcesFormatted = "";
        for (const [key, value] of Object.entries(resources)) {
            resourcesFormatted += `<b>${key}:</b> ${value}<br>`;
        }

        document.getElementById("results").innerHTML = `
            <h3>Writing Prompt:</h3>
            <p>${writingPrompt}</p>
            <h3>Vocabulary Exercise:</h3>
            <p>${vocabExercise}</p>
            <h3>Grammar Explanation:</h3>
            <p>${grammarExplanation}</p>
            <h3>Grammar Exercise:</h3>
            <p>${grammarExercise}</p>
            <h3>Resources for ${learningStyle} Learners:</h3>
            <p>${resourcesFormatted}</p>
        `;
    } else {
        document.getElementById("results").innerHTML = "No learning content available for the selected topic and proficiency level.";
    }
}

function toggleSignupFormVisibility() {
    const signUpForm = document.getElementById('signUpForm');
    signUpForm.style.display = signUpForm.style.display === 'none' ? 'block' : 'none';
}

function handleSignupFormSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const newUser = {
        name: formData.get('name'),
        username: formData.get('name'),
        countryofOrigin: formData.get('countryofOrigin'),
        languagesSpoken: formData.get('languagesSpoken').split(','),
        major: formData.get('major'),
        specialization: formData.get('specialization'),
        classes: formData.get('classes').split(',')
    };
    
    const userProfiles = JSON.parse(localStorage.getItem('userProfiles')) || [];
    userProfiles.push(newUser);
    localStorage.setItem('userProfiles', JSON.stringify(userProfiles));
    displayUser(newUser);
    event.target.reset();
}

function displayUser(user) {
    const userCardsContainer = document.getElementById('userCards');
    userCardsContainer.innerHTML = '';

    const userCard = document.createElement('div');
    userCard.classList.add('card');

    userCard.innerHTML = `
        <div class="card-header">${user.name}</div>
        <div class="card-body">
            <p>Country of Origin: ${user.countryofOrigin}</p>
            <p>Languages Spoken: ${user.languagesSpoken.join(', ')}</p>
            <p>Major: ${user.major}</p>
            <p>Specialization: ${user.specialization}</p>
            <p>Classes: ${user.classes.join(', ')}</p>
        </div>
    `;

    userCardsContainer.appendChild(userCard);
}

function setupFormListeners() {
    document.getElementById('learningForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const learningStyle = document.getElementById('learningStyle').value;
        const proficiencyLevel = document.getElementById('proficiencyLevel').value;
        displayLearningContent(learningStyle, proficiencyLevel);
    });

    document.getElementById('signUpButton').addEventListener('click', toggleSignupFormVisibility);
    document.getElementById('signUpForm').addEventListener('submit', handleSignupFormSubmit);
    document.getElementById('loginForm').addEventListener('submit', handleLoginFormSubmit);
}

function handleLoginFormSubmit(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const userProfiles = JSON.parse(localStorage.getItem('userProfiles')) || [];
    const user = userProfiles.find(user => user.name === username);

    const loginError = document.getElementById('loginError');

    if (user) {
        loginError.textContent = '';
        displayUser(user);
    } else {
        loginError.textContent = 'Username not found. Please check your username or sign up.';
    }
}

function displayUser(user) {
    const userCardsContainer = document.getElementById('userCards');
    userCardsContainer.innerHTML = '';

    const userCard = document.createElement('div');
    userCard.classList.add('card');

    userCard.innerHTML = `
        <div class="card-header">${user.name}</div>
        <div class="card-body">
            <p>Country of Origin: ${user.countryofOrigin}</p>
            <p>Languages Spoken: ${user.languagesSpoken.join(', ')}</p>
            <p>Major: ${user.major}</p>
            <p>Specialization: ${user.specialization}</p>
            <p>Classes: ${user.classes.join(', ')}</p>
        </div>
    `;

    userCardsContainer.appendChild(userCard);
}

function displayRandomAffirmation() {
    const affirmations = ["You're doing great!", "Keep up the good work!", "Your effort is paying off!"];
    const randomIndex = Math.floor(Math.random() * affirmations.length);
    document.getElementById('affirmationContainer').innerText = affirmations[randomIndex];
}