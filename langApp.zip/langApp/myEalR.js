
const proficiencyLevels = [
    "Beginner",
    "Elementary",
    "Intermediate",
    "Upper Intermediate",
    "Advanced",
    "Proficient"
];

console.log(proficiencyLevels);
const learningStylesSimplified = {
    Visual: "Prefers visual aids like images and maps.",
    Auditory: "Learns best through listening and speaking.",
    ReadAndWrite: "Prefers learning through words, reading, and writing.",
    Kinesthetic: "Learns best through hands-on activities."
};

console.log(learningStylesSimplified);
const languageLearningContent = {
    Travel: {
        Beginner: {
            WritingPrompt: "Write about your dream vacation. Where would you go? What would you see?",
            VocabularyExercise: "Learn and use basic travel-related words like 'plane,' 'train,' 'hotel,' 'beach,' 'mountain.'"
        },
        Elementary: {
            WritingPrompt: "Describe a place you have visited. What did you do there? How did you feel?",
            VocabularyExercise: "Focus on simple past tense verbs related to travel activities and descriptive adjectives."
        },
        Intermediate: {
            WritingPrompt: "Compare two cities or countries you know or have visited. What are the differences and similarities?",
            VocabularyExercise: "Use comparative and superlative forms, along with specific travel and cultural vocabulary."
        },
        UpperIntermediate: {
            WritingPrompt: "Discuss the impact of tourism on a destination. Consider both positive and negative aspects.",
            VocabularyExercise: "Incorporate terminology related to economics and environmental science."
        },
        Advanced: {
            WritingPrompt: "Analyze the role of technology in modern travel. How has it changed the way we plan and experience our travels?",
            VocabularyExercise: "Use tech-related vocabulary and persuasive language to argue a point."
        },
        Proficient: {
            WritingPrompt: "Write a detailed proposal for a travel project that addresses a current issue in the travel industry.",
            VocabularyExercise: "Utilize specialized terms from fields like project management, marketing, and cultural studies."
        }
    }
};

// Access:
const proficiencyLevel1 = "Intermediate";
const topic1 = "Travel";
const prompt = languageLearningContent[topic1][proficiencyLevel1].WritingPrompt;
const vocab = languageLearningContent[topic1][proficiencyLevel1].VocabularyExercise;

console.log(`Level: ${proficiencyLevel1}`);
console.log(`Writing Prompt: ${prompt}`);
console.log(`Vocabulary Exercise: ${vocab}`);
const grammarLearningContent = {
    Tenses: {
        Beginner: {
            Explanation: "Present Simple vs. Present Continuous",
            Exercise: "Identify and use the correct tense in daily routines."
        },
        Elementary: {
            Explanation: "Past Simple vs. Present Perfect",
            Exercise: "Write sentences about your last holiday using the correct tense."
        },
        Intermediate: {
            Explanation: "Future Forms - will, going to, and present continuous",
            Exercise: "Plan a future event and describe it using different future forms."
        },
        UpperIntermediate: {
            Explanation: "Perfect Tenses - Present Perfect Continuous and Past Perfect",
            Exercise: "Describe an ongoing action in the past and its relevance to the present."
        },
        Advanced: {
            Explanation: "Conditional Sentences - Zero, First, Second, Third Conditionals",
            Exercise: "Write conditional sentences to express different situations."
        },
        Proficient: {
            Explanation: "Mixed Conditionals and Wish/If only sentences",
            Exercise: "Express regrets and hypothetical situations using mixed conditionals and wish/if only constructions."
        }
    },
    VerbForms: {
        Beginner: {
            Explanation: "Base form, Past Simple, and -ing form",
            Exercise: "Create sentences using verbs in different forms."
        },
        Elementary: {
            Explanation: "Irregular Verbs",
            Exercise: "Fill in the blanks with the correct form of the irregular verbs."
        },
        Intermediate: {
            Explanation: "Modals for possibility and permission",
            Exercise: "Express possibility and ask for permission using modal verbs."
        },
        UpperIntermediate: {
            Explanation: "Passive Voice",
            Exercise: "Rewrite active sentences in passive voice."
        },
        Advanced: {
            Explanation: "Reported Speech",
            Exercise: "Convert direct speech into reported speech."
        },
        Proficient: {
            Explanation: "Subjunctive Mood",
            Exercise: "Use the subjunctive mood to express wishes, demands, and suggestions."
        }
    }
};

// Access:
const level = "Advanced";
const topic = "VerbForms";
const explanation = grammarLearningContent[topic][level].Explanation;
const exercise = grammarLearningContent[topic][level].Exercise;

console.log(`Level: ${level}`);
console.log(`Grammar Topic: ${topic}`);
console.log(`Explanation: ${explanation}`);
console.log(`Exercise: ${exercise}`);
const travelResourcesForLearningStyles = {
    Visual: {
        InteractiveMaps: "Use Google Earth or virtual museum tours to visually explore new destinations.",
        InfographicsAndPhotoJournals: "Find travel infographics and photo journals on Pinterest or Instagram."
    },
    Auditory: {
        TravelPodcastsAndAudiobooks: "Listen to travel podcasts and audiobooks on Spotify or Audible.",
        LanguageLearningApps: "Use Duolingo or Rosetta Stone for auditory language learning."
    },
    ReadAndWrite: {
        TravelBlogsAndEBooks: "Read detailed guides and personal travel experiences on travel blogs. Find eBooks about travel on Kindle.",
        TravelForums: "Engage in travel forums like TripAdvisor or Lonely Planet to share knowledge and experiences."
    },
    Kinesthetic: {
        InteractiveLanguageLearning: "Learn new languages through interactive apps like Memrise, simulating real-life conversations.",
        DIYTravelPlanningTools: "Plan trips interactively with Roadtrippers or Google Trips, and explore cooking through YouTube tutorials."
    }
};

function displayLearningContent(learningStyle, proficiencyLevel) {
    
    const topic = "Travel"; 
    const writingPrompt = languageLearningContent[topic][proficiencyLevel]?.WritingPrompt || "No writing prompt available for this level.";
    const vocabExercise = languageLearningContent[topic][proficiencyLevel]?.VocabularyExercise || "No vocabulary exercise available for this level.";
  
    const grammarExplanation = grammarLearningContent["Tenses"][proficiencyLevel]?.Explanation || "No grammar explanation available for this level.";
    const grammarExercise = grammarLearningContent["Tenses"][proficiencyLevel]?.Exercise || "No grammar exercise available for this level.";
  
    const resources = travelResourcesForLearningStyles[learningStyle] || {};
    let resourcesFormatted = "";
    for (const [key, value] of Object.entries(resources)) {
      resourcesFormatted += `<b>${key}:</b> ${value}<br>`;
    }
  
    // Content in the #results div
    document.getElementById("results").innerHTML = `
      <h3>Writing Prompt:</h3>
      <p>${writingPrompt}</p>
      <h3>Vocabulary Exercise:</h3>
      <p>${vocabExercise}</p>
      <h3>Grammar Explanation:</h3>
      <p>${grammarExplanation}</p>
      <h3>Grammar Exercise:</h3>
      <p>${grammarExercise}</p>
      <h3>Resources for ${learningStyle} Learners:</h3>
      <p>${resourcesFormatted}</p>
    `;
  }
  document.addEventListener('DOMContentLoaded', function() {
    const learningStyleSelect = document.getElementById('learningStyle');
    const proficiencyLevelSelect = document.getElementById('proficiencyLevel');

    // Function to call displayLearningContent with current selections
    function updateContent() {
        const learningStyle = learningStyleSelect.value;
        const proficiencyLevel = proficiencyLevelSelect.value;
        displayLearningContent(learningStyle, proficiencyLevel);
    }

    const form = document.getElementById('learningForm');
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the traditional form submission
        updateContent(); // Update the content based on current selections
    });

    learningStyleSelect.addEventListener('change', updateContent);
});

var userInoussa = {
    name: "Inoussa",
    countryofOrigin: "Burkina Faso",
    languagesSpoken: ["MoorÃ©", "English", "French", "Japanese", "German", "Dioula"],
    major: "Educational Studies",
    specialization: "Language education, educational technology",
    classes: ["TEAC859", "TEAC995A", "TEAC882B", "TEAC882B"]
};


userInoussa.lastName = "Malgoubri";
userInoussa.graduationYear = 2025;
userInoussa.languagesSpoken.push("Bissa");

function getProperty(user, property) {
    return user[property];
}

class UserEal {
    constructor(name, countryofOrigin, languagesSpoken, major, specialization, classes) {
        this.name = name;
        this.countryofOrigin = countryofOrigin;
        this.languagesSpoken = languagesSpoken;
        this.major = major;
        this.specialization = specialization;
        this.classes = classes;
    }
    
    getProperty(property) {
        return this[property];
    }
}

function createUserFromJSON(json) {
    return new UserEal(
        json.name,
        json.countryofOrigin,
        json.languagesSpoken,
        json.major,
        json.specialization,
        json.classes
    );
}


var userInoussaEal = createUserFromJSON(userInoussa);


var userNdrao = new UserEal("Ndrao", "Senegal", ["Wolof", "English", "French"], "Educational Studies", "language education", ["TEAC813K", "TEAC882B"]);
var userBen = new UserEal("Ben", "United States", ["English"], "Educational Studies", "Special Education, Educational Technology", ["TEAC859", "TEAC882D", "TEAC882B"]);
var userAzadeh = new UserEal("Azadeh", "Iran", ["Persian", "Arabic", "English", "German", "Spanish"], "Educational Studies", "Educational Technology", ["TEAC882D", "TEAC882B"]);
var userIlya = new UserEal("Ilya", "Russia", ["Russian", "English"], "educational studies", "language education", ["TEAC859", "TEAC882B"]);
var userKimberly = new UserEal("Kimberly", "United States", ["English"], "Mathematics", "Mathematics Education", ["MATH999", "TEAC882B"]);
var userMichael = new UserEal("Michael", "United States", ["English", "Spanish"], "Educational Studies", "Language Education, Educational Technology", ["MODL999", "TEAC882B"]);

// Array of all users
var users = [userInoussaEal, userNdrao, userBen, userAzadeh, userIlya, userKimberly, userMichael];


console.log(getProperty(userInoussaEal, "name")); 
users.forEach(user => console.log(user.getProperty('name'))); 

function displayUsers(users) {
    const container = document.getElementById('userCards');
    if (!container) {
        console.error('The container for user cards does not exist.');
        return;
    }
    
    container.innerHTML = ''; 

    users.forEach(user => {
        const cardHTML = `
            <div class="card">
                <div class="card-header">${user.name}</div>
                <div class="card-body">
                    <p>Country of Origin: ${user.countryofOrigin}</p>
                    <p>Languages Spoken: ${user.languagesSpoken.join(', ')}</p>
                    <p>Major: ${user.major}</p>
                    <p>Specialization: ${user.specialization}</p>
                    <p>Classes: ${user.classes.join(', ')}</p>
                </div>
            </div>
        `;
        container.innerHTML += cardHTML;
    });
}


document.addEventListener('DOMContentLoaded', function() {
    displayUsers(users);
});
displayUsers(users);

// Login Form
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const loginError = document.getElementById('loginError');
    const userCardsContainer = document.getElementById('userCards');
    const showAllProfilesButton = document.getElementById('showAllProfilesButton');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault(); 

        const username = document.getElementById('username').value;

        const user = users.find(user => user.name === username);

        if (user) {
            
            loginError.textContent = ''; 

            const allUserCards = userCardsContainer.querySelectorAll('.card');
            allUserCards.forEach(card => {
                card.style.display = 'none';
            });

            const userCard = userCardsContainer.querySelector(`#userCard-${username}`);
            if (userCard) {
                userCard.style.display = 'block';
            } else {
                loginError.textContent = 'User profile not found.';
            }
        } else {
            loginError.textContent = 'Username not found. Please check username or sign up.';
        }
    });

    function showAllProfiles() {
        const allUserCards = userCardsContainer.querySelectorAll('.card');
        allUserCards.forEach(card => {
            card.style.display = 'block';
        });
    }

    showAllProfilesButton.addEventListener('click', showAllProfiles);

    function displayUserProfiles() {
        userCardsContainer.innerHTML = '';

        users.forEach(user => {
            const cardHTML = `
                <div id="userCard-${user.name}" class="card" style="display: none;">
                    <div class="card-header">${user.name}</div>
                    <div class="card-body">
                        <p>Country of Origin: ${user.countryofOrigin}</p>
                        <p>Languages Spoken: ${user.languagesSpoken.join(', ')}</p>
                        <p>Major: ${user.major}</p>
                        <p>Specialization: ${user.specialization}</p>
                        <p>Classes: ${user.classes.join(', ')}</p>
                    </div>
                </div>
            `;
            userCardsContainer.innerHTML += cardHTML;
        });
    }

    displayUserProfiles();
});


const entities = [
    "882 B class",
    "Dr Olmanson",
    "Justin",
    "Inoussa",
    "Azadeh",
    "Olmanson",
    "Ben",
];


function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]]; // Swap elements
    }
}

shuffleArray(entities);

function displayRandomAffirmation() {
    
    if (entities.length === 0) {
        shuffleArray(entities); 
    }
    const randomEntity = entities.pop(); 

    const messages = [
        "believes in your potential to excel.",
        "is proud of the progress you've made.",
        "supports your learning journey every step of the way.",
        "is amazed by your dedication and hard work.",
        "cheers for your success and continuous improvement.",
        "stands with you as you overcome learning challenges.",
        "is inspired by your commitment to growing your knowledge."
    ];

    const randomMessage = messages[Math.floor(Math.random() * messages.length)];

  
    const affirmationMessage = `${randomEntity} ${randomMessage}`;

    const affirmationContainer = document.getElementById("affirmationContainer");
    if (affirmationContainer) {
        affirmationContainer.innerText = affirmationMessage;
    } else {
        console.error('Keep Learning.');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    displayRandomAffirmation(); // Initial display

    const userInput = document.getElementById("userInput");

    // On Input change
    userInput.addEventListener("change", function() {
        displayRandomAffirmation();
    });
});
document.addEventListener('DOMContentLoaded', function() {
    let users = []; // Array to store user profiles
    
const storedUsers = JSON.parse(localStorage.getItem('userProfiles'));
    if (storedUsers) {
        users = storedUsers;
    }
    
    users = users.concat([
        userNdrao,
        userBen,
        userAzadeh,
        userIlya,
        userKimberly,
        userMichael
    ]);
    
    // Function to handle form submissions
    function setupFormSubmission() {
        const signUpForm = document.querySelector('#signUpForm');
        if (signUpForm) {
            signUpForm.addEventListener('submit', handleSignupFormSubmit);
        }
        console.log('Form submission setup completed.');
    }

 
    const signUpButton = document.getElementById('signUpButton');
    const signUpForm = document.getElementById('signUpForm');
    function toggleSignupForm() {
        console.log('Sign-up button clicked');
        signUpForm.style.display = signUpForm.style.display === 'none' ? 'block' : 'none';
    }
    signUpButton.addEventListener('click', toggleSignupForm);
    console.log('Initial display status:', signUpForm.style.display);

    // Function to handle sign-up form submission
    function handleSignupFormSubmit(event) {
        event.preventDefault(); // Prevent the default form submission

     // Gather form data
    const formData = {
        name: document.getElementById('nameInput').value, // Updated ID here
        countryofOrigin: document.getElementById('countryDropdown').value,
        languagesSpoken: document.getElementById('languagesSpokenInput').value.split(','),
        major: document.getElementById('majorInput').value,
        specialization: document.getElementById('specializationInput').value,
        classes: document.getElementById('classesInput').value.split(',')
    };
  
   formData.username = formData.name;


        const newUser = createUserFromFormData(formData);

        // Add the current date to the new user
        newUser.dateJoined = new Date().toISOString();

        console.log('New user:', newUser);

        users.push(newUser);
        console.log('User added to the array:', users);

    localStorage.setItem('userProfiles', JSON.stringify(users));
    
        displayUsers(users);

        clearForm('#signUpForm');
        console.log('Form cleared after submission.');

        signUpForm.style.display = 'none';
    }

    // Function to create a new user object from form data
    function createUserFromFormData(formData) {
        const { name, countryofOrigin, languagesSpoken, major, specialization, classes } = formData;
        return new UserEal(name, countryofOrigin, languagesSpoken, major, specialization, classes);
    }

    // Function to clear form fields after submission
    function clearForm(formSelector) {
        const form = document.querySelector(formSelector);
        if (form) {
            form.reset();
            console.log('Form fields cleared.');
        }
    }

    // Function to display user profiles
    function displayUsers(users) {
        const userCardsContainer = document.getElementById('userCards');
        if (!userCardsContainer) {
            console.error('The container for user cards does not exist.');
            return;
        }
        
        userCardsContainer.innerHTML = ''; // Clear previous content

        users.forEach((user, index) => {
            const cardHTML = `
                <div class="card">
                    <div class="card-header">${user.name}</div>
                    <div class="card-body">
                        <p>Country: ${user.countryofOrigin}</p>
                        <p>Languages Spoken: ${user.languagesSpoken.join(', ')}</p>
                        <p>Major: ${user.major}</p>
                        <p>Specialization: ${user.specialization}</p>
                        <p>Classes: ${user.classes.join(', ')}</p>
                    </div>
                </div>
            `;
            userCardsContainer.innerHTML += cardHTML;
        });
    }

    // Function to populate a dropdown element from an array
    function populateDropdownFromArray(selectElement, dataArray) {
        const dropdown = document.getElementById(selectElement);
        dropdown.innerHTML = '';

        dataArray.forEach(item => {
            const option = document.createElement('option');
            option.text = item;
            option.value = item;
            dropdown.appendChild(option);
        });
        console.log('Dropdown populated:', selectElement);
    }

    // Call populateDropdownFromArray for the country dropdown after DOM is loaded
   const countryofOrigin = ["Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Ivory Coast", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"];

    populateDropdownFromArray('countryDropdown', countryofOrigin);

  
    setupFormSubmission();
});
// Fetching Data
function fetchDataAndPopulateUI() {
    fetch('eaL.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            populateProficiencyLevels(data.proficiencyLevels);
            populateLearningStyles(data.learningStylesSimplified);
            populateCountryDropdown();
            //  to load user profiles immediately, uncomment the next line
            // loadUserProfiles(data.users);
        })
        .catch(error => console.error('Error fetching data:', error));
}