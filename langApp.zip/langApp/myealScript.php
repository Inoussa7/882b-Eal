<?php
// Connect to MySQL database
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database_name";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle AJAX request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the learning style and proficiency level from the request
    $learningStyle = $_POST['learningStyle'];
    $proficiencyLevel = $_POST['proficiencyLevel'];

    // Perform SQL queries to fetch data based on learning style and proficiency level
    $sql = "SELECT * FROM your_table WHERE learning_style = '$learningStyle' AND proficiency_level = '$proficiencyLevel'";
    $result = $conn->query($sql);

    // Convert the result into an associative array
    $rows = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    }

    // Close the database connection
    $conn->close();

    // Return the data as JSON
    echo json_encode($rows);
} else {
    // Handle other HTTP methods if needed
    http_response_code(405); // Method Not Allowed
    echo "Method Not Allowed";
}
?>
