// Create entities
CREATE 
  (learningStyle1:LearningStyle {name: "Visual"}),
  (learningStyle2:LearningStyle {name: "Auditory"}),
  (learningStyle3:LearningStyle {name: "Kinesthetic"}),
  (learningStyle4:LearningStyle {name: "Read and Write"}),

  (proficiencyLevel1:ProficiencyLevel {name: "Beginner"}),
  (proficiencyLevel2:ProficiencyLevel {name: "Elementary"}),
  (proficiencyLevel3:ProficiencyLevel {name: "Intermediate"})
  (proficiencyLevel4:ProficiencyLevel {name: "Upper Intermediate"}),,
  (proficiencyLevel5:ProficiencyLevel {name: "Advanced"}),
  (proficiencyLevel6:ProficiencyLevel {name: "Proficient"}),

  (language1:Language {name: "English"}),
  (language2:Language {name: "Spanish"}),
  (language3:Language {name: "French"}),
  (language4:Language {name: "Mooré"}),
  (language5:Language {name: "German"}),
  (language5:Language {name: "Russian"}),
  (language7:Language {name: "Arabic"}),
  (language8:Language {name: "Persian"}),
  (language9:Language {name: "Wolof"}),
  (language10:Language {name: "Japanese"}),
  (language11:Language {name: "Chinese"}),

  (major1:Major {name: "Computer Science"}),
  (major2:Major {name: "Business Administration"}),
  (major3:Major {name: "Psychology"}),
  (major4:Major {name: "Education"}),
  (major5:Major {name: "Engineering"}),

  (specialization3:Specialization {name: "Educational Technologies"}),
  (specialization3:Specialization {name: "Languages"}),
  (specialization3:Specialization {name: "Mathematics"}),
  (specialization4:Specialization {name: "Medical Science"}),
  (specialization5:Specialization {name: "Computer Science"}),
  (specialization6:Specialization {name: "Data Science"}),
  (specialization7:Specialization {name: "Finance"}),
  (specialization8:Specialization {name: "Clinical Psychology"}),

  (country1:Country {name: "USA"}),
  (country2:Country {name: "Canada"}),
  (country3:Country {name: "UK"}),

  (eslLesson1:ESLLesson {name: "EAL Lesson 1"}),
  (eslLesson2:ESLLesson {name: "EAL Lesson 2"}),
  (eslLesson3:ESLLesson {name: "EAL Lesson 3"}),

  (worksheet1:Worksheet {name: "Speaking Worksheet"}),
  (worksheet2:Worksheet {name: "Reading Worksheet"}),
  (worksheet3:Worksheet {name: "Listening Worksheet"}),
  (worksheet4:Worksheet {name: "Writing Worksheet"});

// Create relationships
MATCH (learningStyle1:LearningStyle {name: "Visual"}),
      (learningStyle2:LearningStyle {name: "Auditory"}),
      (learningStyle3:LearningStyle {name: "Kinesthetic"}),
      (proficiencyLevel1:ProficiencyLevel {name: "Beginner"}),
      (proficiencyLevel2:ProficiencyLevel {name: "Intermediate"}),
      (proficiencyLevel3:ProficiencyLevel {name: "Advanced"}),
      (language1:Language {name: "English"}),
      (language2:Language {name: "Spanish"}),
      (language3:Language {name: "French"}),
      (major1:Major {name: "Computer Science"}),
      (major2:Major {name: "Business Administration"}),
      (major3:Major {name: "Psychology"}),
      (specialization1:Specialization {name: "Data Science"}),
      (specialization2:Specialization {name: "Finance"}),
      (specialization3:Specialization {name: "Clinical Psychology"}),
      (country1:Country {name: "USA"}),
      (country2:Country {name: "Canada"}),
      (country3:Country {name: "UK"}),
      (eslLesson1:ESLLesson {name: "ESL Lesson 1"}),
      (eslLesson2:ESLLesson {name: "ESL Lesson 2"}),
      (eslLesson3:ESLLesson {name: "ESL Lesson 3"}),
      (worksheet1:Worksheet {name: "Speaking Worksheet"}),
      (worksheet2:Worksheet {name: "Reading Worksheet"}),
      (worksheet3:Worksheet {name: "Listening Worksheet"}),
      (worksheet4:Worksheet {name: "Writing Worksheet"})
CREATE
  // Connect learners with learning styles
  (learningStyle1)-[:HAS_STYLE]->(learner1:Learner {name: "Alice"}),
  (learningStyle2)-[:HAS_STYLE]->(learner2:Learner {name: "Bob"}),
  (learningStyle3)-[:HAS_STYLE]->(learner3:Learner {name: "Charlie"}),

  // Connect learners with proficiency levels
  (learner1)-[:HAS_PROFICIENCY]->(proficiencyLevel1),
  (learner2)-[:HAS_PROFICIENCY]->(proficiencyLevel2),
  (learner3)-[:HAS_PROFICIENCY]->(proficiencyLevel3),

  // Connect learners with languages spoken
  (learner1)-[:SPEAKS]->(language1),
  (learner2)-[:SPEAKS]->(language2),
  (learner3)-[:SPEAKS]->(language3),

  // Connect learners with majors
  (learner1)-[:STUDIES]->(major1),
  (learner2)-[:STUDIES]->(major2),
  (learner3)-[:STUDIES]->(major3),

  // Connect majors with specializations
  (major1)-[:HAS_SPECIALIZATION]->(specialization1),
  (major2)-[:HAS_SPECIALIZATION]->(specialization2),
  (major3)-[:HAS_SPECIALIZATION]->(specialization3),

  // Connect learners with countries of origin
  (learner1)-[:FROM]->(country1),
  (learner2)-[:FROM]->(country2),
  (learner3)-[:FROM]->(country3),

  // Connect ESL lessons with worksheets
  (eslLesson1)-[:CONTAINS]->(worksheet1),
  (eslLesson2)-[:CONTAINS]->(worksheet2),
  (eslLesson3)-[:CONTAINS]->(worksheet3),
  (eslLesson3)-[:CONTAINS]->(worksheet4);
