const { Duolingo } = require('@grimille/duolingo-js');

async function getDuolingoData(username, password) {
  const client = new Duolingo(username, password);

  try {
    const logged = await client.login();
    if (logged) {
      await client.loadSelfUserData();
      const totalXP = client.getTotalXP();
      const streak = client.getStreak();
      const username = client.getUsername();
      const displayName = client.getDisplayName();
      const isPremium = client.isPremium();
      const userId = client.getId();
      const profileCountry = client.getProfileCountry();
      const courses = client.getCourses();
      const friends = client.getFriends();

      // Return the retrieved data as an object
      return {
        totalXP,
        streak,
        username,
        displayName,
        isPremium,
        userId,
        profileCountry,
        courses,
        friends
      };
    } else {
      console.log('Login failed.');
      return null;
    }
  } catch (error) {
    console.error('Error:', error);
    return null;
  }
}

module.exports = {
  getDuolingoData
};